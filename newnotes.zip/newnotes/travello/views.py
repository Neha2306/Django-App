from django.shortcuts import render
from .models import Destination
# Create your views here.

def index(request):

    # des1 = Destination()
    # des1.offer = True
    # des1.name = 'Mumbai'
    # des1.desc = 'city cannot sleeps'
    # des1.img = 'destination_1.jpg'
    # des1.price = '1000'

    # des2 = Destination()
    # des2.offer = False
    # des2.name = 'Nagpur'
    # des2.desc = 'Lorem ipsum'
    # des2.img = 'destination_2.jpg'
    # des2.price = '900'

    # des3 = Destination()
    # des3.offer = True
    # des3.name = 'Hydrabad'
    # des3.desc = 'Biryani first, shewani comes'
    # des3.img = 'destination_3.jpg'
    # des3.price = '567'

    # deses = [des1, des2, des3]


    deses = Destination.objects.all()

    return render(request, 'index.html', {'deses':deses})
